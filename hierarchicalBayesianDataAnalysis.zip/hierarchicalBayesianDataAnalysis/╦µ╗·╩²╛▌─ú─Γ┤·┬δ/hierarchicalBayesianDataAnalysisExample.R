# Example for hierarchicalBayesianDataAnalysis.R 
#------------------------------------------------------------------------------- 
# Optional generic preliminaries:
graphics.off() # This closes all of R's graphics windows.
rm(list=ls())  # Careful! This clears all of R's memory!
#------------------------------------------------------------------------------- 
# Create The data file:
y1=round(rnorm(50,mean=90,sd=10))
y2=round(rnorm(50,mean=100,sd=15))
y3=round(rnorm(50,mean=110,sd=5))
y=append(y1,y2)
y=append(y,y3)
s=rep(1,times=50)
s2=rep(2,times=50)
s3=rep(3,times=50)
s=append(s,s2)
s=append(s,s3)
mydata=data.frame(y,s)
yName = "y" # column name for y values
sName = "s" # column name for class ID
# Optional: Specify filename root and graphical format for saving output.
# Otherwise specify as NULL or leave saveName and saveType arguments 
# out of function calls.
fileNameRoot = "C:/Users/xiaokeai/Desktop/" 
graphFileType = "jpg" 
#------------------------------------------------------------------------------- 
# Load the relevant model into R's working memory:
source("hierarchicalBayesianDataAnalysis.R")
#------------------------------------------------------------------------------- 
# Generate the MCMC chain:
mcmcCoda = genMCMC( data=mydata , sName=sName , yName=yName , 
                    numSavedSteps=20000 , saveName=fileNameRoot , thinSteps=10 )
#------------------------------------------------------------------------------- 
# Display diagnostics of chain, for specified parameters:
parameterNames = varnames(mcmcCoda) # get all parameter names for reference
for ( parName in parameterNames[c(1:3,length(parameterNames))] ) { 
  diagMCMC( codaObject=mcmcCoda , parName=parName , 
                saveName=fileNameRoot , saveType=graphFileType )
}
#------------------------------------------------------------------------------- 
# Get summary statistics of chain:
summaryInfo = smryMCMC( mcmcCoda , compVal=0.5 , 
                        diffIdVec=c(1,2,3),  
                        compValDiff=0.0 ,
                        saveName=fileNameRoot )
# Display posterior information:
plotMCMC( mcmcCoda , data=mydata , sName=sName , yName=yName , 
          compVal=0.5 , 
          diffIdVec=c(1,2,3), 
          compValDiff=0.0,
          saveName=fileNameRoot , saveType=graphFileType )
#------------------------------------------------------------------------------- 
